<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
if (isset($detailbody)){
echo $detailbody;   
}
?>
