<?php
/**
 * copyright (C) 2008-2020 GWESystems Ltd - All rights reserved
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

use Joomla\CMS\Language\Text;
use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;
use Joomla\String\StringHelper;
use Joomla\Utilities\ArrayHelper;
use Joomla\CMS\Component\ComponentHelper;

/**
 * HTML View class for the component frontend
 *
 * @static
 */
include_once(JPATH_SITE . "/modules/mod_jevents_legend/tmpl/default/legend.php");

class GeraintModLegendView extends DefaultModLegendView
{

	var $_modid = null;

	var $_params = null;

	function getViewName()
	{

		return "geraint";
	}

	function displayCalendarLegend($style = "list")
	{

		// do not display normal legend if dynamic legend is visible on this page
		$registry = JevRegistry::getInstance("jevents");
		if ($registry->get("jevents.dynamiclegend", 0))
		{
			return;
		}

		// since this is meant to be a comprehensive legend look for catids from menu first:
		$cfg    = JEVConfig::getInstance();
		$Itemid = $this->myItemid;
		$user   = Factory::getUser();
		$app    = Factory::getApplication();
		$input  = $app->input;

		$db = Factory::getDbo();
		// Parameters - This module should only be displayed alongside a com_jevents calendar component!!!
		$cfg = JEVConfig::getInstance();

		$option = $input->getCmd('option');
		if ($this->disable && $option != JEV_COM_COMPONENT) return;

		$catidList = "";

		include_once(JPATH_ADMINISTRATOR . "/components/" . JEV_COM_COMPONENT . "/libraries/colorMap.php");

		$params = ComponentHelper::getParams(JEV_COM_COMPONENT);

		$c      = 0;
		$catids = array();
		// New system
		$newcats = $params->get("catidnew", false);
		if ($newcats && is_array($newcats))
		{
			foreach ($newcats as $newcat)
			{
				if (!in_array($newcat, $catids))
				{
					$catids[]  = $newcat;
					$catidList .= (StringHelper::strlen($catidList) > 0 ? "," : "") . $newcat;
				}
			}
		}
		else
		{
			while ($nextCatId = $params->get("catid$c", null))
			{
				if (!in_array($nextCatId, $catids))
				{
					$catids[]  = $nextCatId;
					$catidList .= (StringHelper::strlen($catidList) > 0 ? "," : "") . $nextCatId;
				}
				$c++;
			}
		}
		$jevleghelper = new modJeventsLegendHelper();
		if ($catidList == "" && $params->get("catid0", "xxx") == "xxx")
		{
			modJeventsLegendHelper::getAllCats($this->_params, $catids, $catidList);
		}

		$separator = $params->get("catseparator", "|");
		$catidsOut = str_replace(",", $separator, $catidList);

		// I should only show legend for items that **can** be shown in calendar so must filter based on GET/POST
		$catidsIn = $input->getString('catids', "NONE");
		if ($catidsIn != "NONE" && $catidsIn != "0") $catidsGP = explode($separator, $catidsIn);
		else $catidsGP = array();
		ArrayHelper::toInteger($catidsGP);
		$catidsGPList = implode(",", $catidsGP);

		// This produces a full tree of categories
		$allrows = $this->getCategoryHierarchy($catidList, $catidsGPList);

		// This is the full set of top level catids
		$availableCatsIds = "";
		foreach ($allrows as $row)
		{
			$availableCatsIds .= (StringHelper::strlen($availableCatsIds) > 0 ? $separator : "") . $row->id;
		}

		$allcats               = new catLegend("0", Text::_('JEV_LEGEND_ALL_CATEGORIES'), "#d3d3d3", Text::_('JEV_LEGEND_ALL_CATEGORIES_DESC'));
		$allcats->activeBranch = true;

		array_push($allrows, $allcats);
		if (count($allrows) == 0) return "";
		else
		{

			if ($Itemid < 999999) $itm = "&Itemid=$Itemid";
			$task = $input->getString('jevcmd', $cfg->get('com_startview'));

			list($year, $month, $day) = JEVHelper::getYMD();
			$tsk = "";
			if ($task == "month.calendar" || $task == "year.listeventsevents" || $task == "week.listevents" || $task == "year.listevents" || $task == "day.listevents" || $task == "cat.listevents")
			{
				$tsk = "&task=$task&year=$year&month=$month&day=$day";
			}
			else
			{
				$tsk = "&task=$this->myTask&year=$year&month=$month&day=$day";
			}
			switch ($style)
			{
				case 'list':
					$content = '<div class="event_legend_container">';
					$content .= '<table border="0" cellpadding="0" cellspacing="5" width="100%">';
					foreach ($allrows as $row)
					{

						if (isset($row->activeBranch))
						{
							$content .= $this->listKids($row, $itm, $tsk, $availableCatsIds);
						}
					}
					$content .= "</table>\n";
					$content .= "</div>";
					break;

				case 'block':
				default:
					$content = '<div class="event_legend_container">';
					foreach ($allrows as $row)
					{

						if (isset($row->activeBranch))
						{
							$content .= $this->blockKids($row, $itm, $tsk, $availableCatsIds);
						}
					}
					// stop floating legend items
					$content .= '<br style="clear:both" />' . "</div>\n";
			}

			// only if called from module
			if (isset($this->_params))
			{
				if ($this->_params->get('show_admin', 0) && isset($year) && isset($month) && isset($day) && isset($Itemid))
				{

					// This is only displayed when JEvents is the component so I can get the component view
					$component = ComponentHelper::getComponent(JEV_COM_COMPONENT);

					$registry   = JevRegistry::getInstance("jevents");
					$controller =& $registry->get("jevents.controller", null);
					if (!$controller) return $content;
					$view = $controller->view;

					//include_once(JPATH_SITE."/components/$option/events.html.php");
					ob_start();
					if (method_exists($view, "_viewNavAdminPanel"))
					{
						echo $view->_viewNavAdminPanel();
					}
					$content .= ob_get_contents();
					ob_end_clean();
				}
			}

			return $content;
		}
	}

	function listKids($row, $itm, $tsk, $availableCatsIds, $activeParent = false, $activeSubCat = 0)
	{

		$catclass = "";
		if ($row->parent_id > 0) $catclass = "childcat";
		if ($row->parent_id > 0 && isset($row->activeBranch)) $catclass = "activechildcat";
		if ($row->parent_id > 0 && $activeParent) $catclass = "activechildcat";
		if ($row->parent_id > 0 && $activeSubCat > 0 && $row->id != $activeSubCat && !isset($row->activeNode)) $catclass = "childcat";

		$cat     = $row->id > 0 ? "&catids=$row->id" : "";
		$content = "<tr><td style='border:solid 1px #000000;height:5px;width:5px;background-color:" . $row->color . "'></td>\n"
			. "<td class='legend' >"
			. "<a style='text-decoration:none' href='" . Route::_("index.php?option=" . JEV_COM_COMPONENT . "$cat$itm$tsk") . "' title='" . JEventsHTML::special($row->name) . "'>"
			. JEventsHTML::special($row->name) . "</a></td></tr>\n";

		if (isset($row->activeBranch) && isset($row->subcats))
		{
			$activeSubCat = 0;
			foreach ($row->subcats as $subcatid => $subcat)
			{
				if (isset($subcat->activeBranch))
				{
					$activeSubCat = $subcatid;
				}
			}
			foreach ($row->subcats as $subcatid => $subcat)
			{
				$content .= $this->listKids($subcat, $itm, $tsk, $availableCatsIds, isset($row->activeNode), $activeSubCat);
			}
		}

		return $content;


	}

	function blockKids($row, $itm, $tsk, $availableCatsIds, $activeParent = false, $activeSubCat = 0)
	{

		$catclass = "";
		if ($row->parent_id > 0) $catclass = "childcat";
		if ($row->parent_id > 0 && isset($row->activeBranch)) $catclass = "activechildcat";
		if ($row->parent_id > 0 && $activeParent) $catclass = "activechildcat";
		if ($row->parent_id > 0 && $activeSubCat > 0 && $row->id != $activeSubCat && !isset($row->activeNode)) $catclass = "childcat";

		$cat = $row->id > 0 ? "&catids=$row->id" : "";
		//$rowparams = new JevRegistry(isset($row->params)?$row->params:null);
		//$image = $rowparams->get("image",false);
		//$image = $image? "<img src = '".JURI::root().$image."' class='catimage'  alt='categoryimage' />" : "";
		$content = '<div class="event_legend_item ' . $catclass . '" style="border-color:' . $row->color . '">';
		$content .= '<div class="event_legend_name" style="border-color:' . $row->color . '">'
			. '<a href="' . Route::_("index.php?option=" . JEV_COM_COMPONENT . "$cat$itm$tsk") . '" title="' . JEventsHTML::special($row->name) . '">'
			. JEventsHTML::special($row->name) . '</a>';
		$content .= '</div>' . "\n";
		if (StringHelper::strlen($row->description) > 0)
		{
			$content .= '<div class="event_legend_desc"  style="border-color:' . $row->color . '">' . $row->description . '</div>';
		}
		$content .= '</div>' . "\n";

		if (isset($row->activeBranch) && isset($row->subcats))
		{
			$activeSubCat = 0;
			foreach ($row->subcats as $subcatid => $subcat)
			{
				if (isset($subcat->activeBranch))
				{
					$activeSubCat = $subcatid;
				}
			}
			foreach ($row->subcats as $subcatid => $subcat)
			{
				$content .= $this->blockKids($subcat, $itm, $tsk, $availableCatsIds, isset($row->activeNode), $activeSubCat);
			}
		}

		return $content;

	}

}
