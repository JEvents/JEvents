<?php
/**
 * Created by PhpStorm.
 * User: tonypartridge
 * Date: 2019-03-25
 * Time: 07:52
 */

echo 'View hit.';