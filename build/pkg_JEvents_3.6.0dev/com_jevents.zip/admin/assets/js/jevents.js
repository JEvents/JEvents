/**
 * @version    CVS: 3.6.0dev
 * @package    com_yoursites
 * @author     Geraint Edwards
 * @copyright  2017--2020 GWESystems Ltd
 * @license    GNU General Public License version 3 or later; see LICENSE.txt
 */

