<?php
/**
 * JEvents Component for Joomla! 3.x
 *
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die();

JLoader::register('JFormFieldText', JPATH_SITE . '/libraries/joomla/form/fields/text.php');
//J4 = JLoader::register('JFormFieldText', JPATH_SITE . '/libraries/src/Form/Field/TextField.php');

class JFormFieldJevtext extends JFormFieldText
{
	protected function getInput()
	{

		JLoader::register('JEVHelper', JPATH_SITE . "/components/com_jevents/libraries/helper.php");
		JEVHelper::ConditionalFields($this->element, $this->form->getName());

		return parent::getInput();
	}

}