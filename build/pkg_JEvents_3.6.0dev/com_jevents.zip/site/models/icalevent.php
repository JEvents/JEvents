<?php

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
// Load the backend model file
include(JEV_ADMINPATH . "/models/" . basename(__FILE__));
